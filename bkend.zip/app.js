const express = require("express");
const mongoose = require("mongoose");
const app = express();
const {CurrentUser}= require("./models/currentUser");



// app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use((req, res, next) => {
    res.append('Access-Control-Allow-Origin', ['*']);
    res.append('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.append('Access-Control-Allow-Headers', 'Content-Type');
    next();
}); 



const users = require('./routes/users');
const products=require('./routes/products');
const auth=require('./routes/auth');


app.use('/api/users', users);
app.use('/api/products',products);
app.use('/auth',auth)
//app.use('/',express.static(__dirname + '/public'));




	



app.get('/',(req,res)=>{
    res.sendFile(__dirname + "/public/index.html")
})

mongoose.connect('mongodb+srv://prashant_tomar:qwertyuiop23@clustermeg-dkebi.mongodb.net/test?retryWrites=true&w=majority',({useNewUrlParser: true,
useUnifiedTopology: true}))
    .then(()=> console.log("connected"))
    .catch(err=> console.log("not connected"))

app.get('/currentuser',(req,res)=>{
    let currentUser =  CurrentUser.find({role:"User" });
    console.log("-------------------------------------")
    if(currentUser){
        console.log(currentUser.model)
        res.send(currentUser)
    }
    else{
        res.send("bad request")
    }
})

app.listen("8080");