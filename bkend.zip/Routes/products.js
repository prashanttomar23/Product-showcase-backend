const {Product, validate} = require('../models/products'); 
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth')
const multer =require('multer');
const path = require('path');
const fs = require("fs")


//============image
const storage= multer.diskStorage({
    destination:"./uploads",
    filename: function(req,file,cb){
        cb(null,file.fieldname + "_" + Date.now()+
        path.extname(file.originalname));
    }
});
const upload = multer({
    storage:storage,
}).single("productImage")
//-----------------imgae funtion end---
router.post('/add',( req,res)=>{
    upload(req,res,(err)=>{
        if(err){
            res.send("400")
        }
        else{
            console.log(req.body)
            console.log(req.file);
            product = new Product({ 
                name: req.body.productName,
                price: req.body.productPrice,
                companyTitle:req.body.productCompany,
                image: {
                    data:fs.readFileSync(req.file.path),
                    contentType:"image/png"
                }
        
            });
            let popupMesg=product.name + "Added"
            product = product.save();
            res.redirect("http://localhost:3000/addProduct")
            
            //const prod=Product.find()
            //console.log(prod)
            //res.contentType('json')
            
        }
    })
})

router.get('/', async (req, res) => {
    const product = await Product.find().sort('name');
    res.send(product);
  });
  
router.post('/', async (req, res) => {
    console.log(req.body)
    // upload(req,res,(err)=>{
    //     if(err){
    //         console.log("error",err)
    //     }
    //     else {
    //         console.log("file fron  multer",req
    //         )
    //     }
    // })
    const { error } = validate(req.body); 
    if (error) return res.send("401");
    let product= await Product.findOne({name:req.body.name});
    if(product) return res.send("400")

    product = new Product({ 
        name: req.body.name,
        price: req.body.price,
        companyTitle:req.body.companyTitle,
        image: req.body.image,

    });
    product = await product.save();
    res.send(product);
});

router.put('/:id', async (req, res) => {
    const { error } = validate(req.body); 
    //console.log("eroro her",error,req.params.id)
   // console.log(req.body,"from server body req")
    if (error) return res.send("401")

    let product= await Product.findOne({name:req.body.name});
    if(product) return res.send('400')

    product = await Product.findByIdAndUpdate(req.params.id,
        { 
            name: req.body.name,
            price: req.body.price,
            companyTitle:req.body.companyTitle,
        });
    res.send(product);
});

router.delete('/:id', async (req, res) => {
    console.log(req.params.id)
    const product = await Product.findByIdAndRemove(req.params.id);
    if (!product) return res.status(404).send('Product not found.');

    res.send(product);
    
});

router.get('/:id', async (req, res) => {
    const product = await Product.findById(req.params.id);

    if (!product) return res.status(404).send('Product not found.');

    res.send(product);
});

module.exports = router;